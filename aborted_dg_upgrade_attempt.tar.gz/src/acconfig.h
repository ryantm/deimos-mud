/* Define if we're compiling CircleMUD under any type of UNIX system */
#undef CIRCLE_UNIX

/* Define if the system is capable of using crypt() to encrypt */
#undef CIRCLE_CRYPT

/* Define to `int' if <sys/types.h> doesn't define.  */
#undef ssize_t


